<?php 
$servername="local host";
$username="root";
$password="";
$db="hr system";
$conn =new mysqli($servername,$username,$password,$db);
if($conn->connect-error){
	die("connectionfailed:"$conn->connect-eeror);
}